﻿using E_Grocery_Store.Models.AccountManagement;
using E_Grocery_Store.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Core.UserAccount
{
    public class UserAccount : IUserAccount
    {
        private readonly BasicAuthDBContext basicAuthDBContext;

        public UserAccount(BasicAuthDBContext basicAuthDBContext)
        {
            this.basicAuthDBContext = basicAuthDBContext;
        }

        public Task<ResponseModel> Login(LoginModel loginModel)
        {
            throw new NotImplementedException();
        }

        public async Task<ResponseModel> Registration(RegistrationModel registrationModel)
        {
            try
            {
                var res = await basicAuthDBContext.registrationModels.AddAsync(registrationModel);
                await basicAuthDBContext.SaveChangesAsync();
                if (res != null)
                {
                    ResponseModel responseModel = new ResponseModel();
                    responseModel.Message = "Registration SuccessFull...!";
                    return responseModel;
                }
                else
                {
                    throw new Exception("Registration Failed...!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
