﻿using E_Grocery_Store.Models.AccountManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Core.UserAccount
{
    public interface IUserAccount
    {
        Task<ResponseModel> Registration(RegistrationModel registrationModel);
        Task<ResponseModel> Login(LoginModel loginModel);
    }
}
