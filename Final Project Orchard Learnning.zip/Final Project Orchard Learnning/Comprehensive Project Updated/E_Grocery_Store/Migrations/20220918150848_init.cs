﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace E_Grocery_Store.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "groceryItemModels",
                columns: table => new
                {
                    ItemId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemName = table.Column<string>(nullable: true),
                    ItemPrice = table.Column<double>(nullable: false),
                    ItemDiscription = table.Column<string>(nullable: true),
                    Rating = table.Column<string>(nullable: true),
                    ItemCategoryId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_groceryItemModels", x => x.ItemId);
                });

            migrationBuilder.CreateTable(
                name: "itemCategoryModels",
                columns: table => new
                {
                    ItemCategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ItemCategory = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_itemCategoryModels", x => x.ItemCategoryId);
                });

            migrationBuilder.CreateTable(
                name: "loginModels",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailId = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_loginModels", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "orderModels",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orderModels", x => x.OrderId);
                });

            migrationBuilder.CreateTable(
                name: "registrationModels",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(maxLength: 150, nullable: true),
                    EmailId = table.Column<string>(maxLength: 150, nullable: true),
                    MobileNumber = table.Column<long>(nullable: false),
                    Password = table.Column<string>(maxLength: 150, nullable: true),
                    RoleId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_registrationModels", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "rolesModels",
                columns: table => new
                {
                    RoleId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_rolesModels", x => x.RoleId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "groceryItemModels");

            migrationBuilder.DropTable(
                name: "itemCategoryModels");

            migrationBuilder.DropTable(
                name: "loginModels");

            migrationBuilder.DropTable(
                name: "orderModels");

            migrationBuilder.DropTable(
                name: "registrationModels");

            migrationBuilder.DropTable(
                name: "rolesModels");
        }
    }
}
