﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Models.AccountManagement
{
    public class ResponseModel
    {
        public string Message { get; set; }
    }
}
