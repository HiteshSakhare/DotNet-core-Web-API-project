﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Models.AccountManagement
{
   
    public class RegistrationModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public int UserId { get; set; }

        [StringLength(150)]
        public string UserName { get; set; }

        [StringLength(150)]
        public string EmailId { get; set; }
        public long MobileNumber { get; set; }

        [StringLength(150)]
        public string Password { get; set; }

        public int RoleId { get; set; }

        [NotMapped]
        public string RoleName { get; set; }
    }
}
