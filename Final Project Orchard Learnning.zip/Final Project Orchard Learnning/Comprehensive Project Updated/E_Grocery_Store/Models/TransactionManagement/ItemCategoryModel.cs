﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Models.TransactionManagement
{
    public class ItemCategoryModel
    {
        [Key]
        public int ItemCategoryId { get; set; }
        public string ItemCategory { get; set; }
    }
}
