﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Models.TransactionManagement
{
    public class CartModel
    {

    }
}
