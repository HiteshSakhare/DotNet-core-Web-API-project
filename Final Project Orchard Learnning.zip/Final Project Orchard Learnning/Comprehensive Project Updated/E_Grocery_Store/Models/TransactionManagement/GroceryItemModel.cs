﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace E_Grocery_Store.Models.TransactionManagement
{
    public class GroceryItemModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public double ItemPrice { get; set; }
        public string ItemDiscription { get; set; }
        public string Rating { get; set; }
        public int ItemCategoryId { get; set; }

        [NotMapped]
        public string ItemCategory { get; set; }
    }
}
