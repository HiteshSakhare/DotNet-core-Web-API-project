﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using E_Grocery_Store.Models.AccountManagement;
using E_Grocery_Store.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.Cookies;
using E_Grocery_Store.Core.UserAccount;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace E_Grocery_Store.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [TestClass]
    //[Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class RegistrationController : ControllerBase
    {
        private readonly BasicAuthDBContext _context;
        private readonly IUserAccount userAccount;
        public RegistrationController(BasicAuthDBContext context, IUserAccount userAccount)
        {
            _context = context;
            this.userAccount =userAccount;
        }

        // GET: api/Registration
        [HttpGet]
        [TestMethod]
        public async Task<ActionResult<dynamic>> GetregistrationModels()
        
        {
           // return await _context.registrationModels.ToListAsync();
            var users = (from u in _context.registrationModels
                         join r in _context.rolesModels
                         on u.RoleId equals r.RoleId where u.RoleId==r.RoleId

                         select new 
                         {
                             u.UserName,
                             u.EmailId,
                             u.MobileNumber,
                             u.RoleId,
                             r.RoleName,
                             u.Password
                         }).ToListAsync();
            return await users;
        }

        // GET: api/Registration/5
        [HttpGet("{id}")]
        [TestMethod]
        public async Task<ActionResult<RegistrationModel>> GetRegistrationModel(int id)
        {
            var registrationModel = await _context.registrationModels.FindAsync(id);

            if (registrationModel == null)
            {
                return NotFound();
            }

            return registrationModel;
        }

        // PUT: api/Registration/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [TestMethod]
        public async Task<IActionResult> PutRegistrationModel(int id, RegistrationModel registrationModel)
        {
            if (id != registrationModel.UserId)
            {
                return BadRequest();
            }

            _context.Entry(registrationModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RegistrationModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Registration
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        // [AllowAnonymous]
        [TestMethod]
        public async Task<ActionResult<RegistrationModel>> Registration([FromBody]RegistrationModel registrationModel)
        {
            _context.registrationModels.Add(registrationModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetRegistrationModel", new { id = registrationModel.UserId }, registrationModel);
            //try
            //{
            //    var response = await userAccount.Registration(registrationModel);
            //    return response;
            //}
            //catch (Exception ex)
            //{
            //    ResponseModel responseModel = new ResponseModel();
            //    responseModel.Message = ex.Message;
            //    return responseModel;
            //}
        }
        [HttpPost]
        [Route("login")]
        //[AllowAnonymous]
        [TestMethod]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            try
            {
                //await userDetails.Login(loginModel);
                //.Include(options => options.RoleName).
                var userDetail = await _context.registrationModels.Where(options =>
             options.EmailId == loginModel.EmailId && options.Password == loginModel.Password).FirstOrDefaultAsync();
                if (userDetail == null)
                {
                    throw new Exception("Invalid Cardinals...!Enter Correct Data");
                }
            //    var claims = new List<Claim>
            //{
            //    new Claim(type:ClaimTypes.Email,value:userDetail?.EmailId),
            //    new Claim(type:ClaimTypes.Role,value:userDetail?.RoleName),
            //};
            //    var idetity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            //    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(idetity));
                return Ok("Login SuccessFul...!");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        // DELETE: api/Registration/5
        [HttpDelete("{id}")]
        [TestMethod]
        public async Task<ActionResult<RegistrationModel>> DeleteRegistrationModel(int id)
        {
            var registrationModel = await _context.registrationModels.FindAsync(id);
            if (registrationModel == null)
            {
                return NotFound();
            }

            _context.registrationModels.Remove(registrationModel);
            await _context.SaveChangesAsync();

            return registrationModel;
        }

        private bool RegistrationModelExists(int id)
        {
            return _context.registrationModels.Any(e => e.UserId == id);
        }
    }
}
