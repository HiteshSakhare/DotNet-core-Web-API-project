﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using E_Grocery_Store.Models.TransactionManagement;
using E_Grocery_Store.Repository;
using Microsoft.AspNetCore.Cors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace E_Grocery_Store.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("MyPolicy")]
    [TestClass]
    public class GroceryItemsController : ControllerBase
    {
        private readonly BasicAuthDBContext _context;

        public GroceryItemsController(BasicAuthDBContext context)
        {
            _context = context;
        }

        // GET: api/GroceryItems
        [HttpGet]
        [TestMethod]
        public async Task<ActionResult<IEnumerable<GroceryItemModel>>> GetgroceryItemModels()
        {
            // return await _context.groceryItemModels.ToListAsync();
            
                var items = (from i in _context.groceryItemModels
                             join c in _context.itemCategoryModels
                             on i.ItemCategoryId equals c.ItemCategoryId

                             select new GroceryItemModel
                             {
                                 ItemId = i.ItemId,
                                 ItemName = i.ItemName,
                                 ItemPrice = i.ItemPrice,
                                 ItemDiscription = i.ItemDiscription,
                                 Rating = i.Rating,
                                 ItemCategoryId = i.ItemCategoryId,
                                 ItemCategory = c.ItemCategory

                             }).ToListAsync();
                return await items;
           
        }

        // GET: api/GroceryItems/5
        [HttpGet("{id}")]
        [TestMethod]
        public async Task<ActionResult<GroceryItemModel>> GetGroceryItemModel(int id)
        {
            var groceryItemModel = await _context.groceryItemModels.FindAsync(id);

            if (groceryItemModel == null)
            {
                return NotFound();
            }

            return groceryItemModel;
        }

        // PUT: api/GroceryItems/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [TestMethod]
        public async Task<IActionResult> PutGroceryItemModel(int id, GroceryItemModel groceryItemModel)
        {
            if (id != groceryItemModel.ItemId)
            {
                return BadRequest();
            }

            _context.Entry(groceryItemModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GroceryItemModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GroceryItems
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost("AddItems")]
        [TestMethod]
        public async Task<ActionResult<GroceryItemModel>> PostGroceryItemModel(GroceryItemModel groceryItemModel)
        {
            _context.groceryItemModels.Add(groceryItemModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGroceryItemModel", new { id = groceryItemModel.ItemId }, groceryItemModel);
        }

        // DELETE: api/GroceryItems/5
        [HttpDelete("{id}")]
        [TestMethod]
        public async Task<ActionResult<GroceryItemModel>> DeleteGroceryItemModel(int id)
        {
            var groceryItemModel = await _context.groceryItemModels.FindAsync(id);
            if (groceryItemModel == null)
            {
                return NotFound();
            }

            _context.groceryItemModels.Remove(groceryItemModel);
            await _context.SaveChangesAsync();

            return groceryItemModel;
        }

        private bool GroceryItemModelExists(int id)
        {
            return _context.groceryItemModels.Any(e => e.ItemId == id);
        }
    }
}
