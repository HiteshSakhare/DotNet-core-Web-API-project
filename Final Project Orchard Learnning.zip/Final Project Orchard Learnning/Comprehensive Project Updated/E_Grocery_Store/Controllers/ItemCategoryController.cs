﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using E_Grocery_Store.Models.TransactionManagement;
using E_Grocery_Store.Repository;

namespace E_Grocery_Store.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemCategoryController : ControllerBase
    {
        private readonly BasicAuthDBContext _context;

        public ItemCategoryController(BasicAuthDBContext context)
        {
            _context = context;
        }

        // GET: api/ItemCategory
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ItemCategoryModel>>> GetitemCategoryModels()
        {
            return await _context.itemCategoryModels.ToListAsync();
        }

        // GET: api/ItemCategory/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ItemCategoryModel>> GetItemCategoryModel(int id)
        {
            var itemCategoryModel = await _context.itemCategoryModels.FindAsync(id);

            if (itemCategoryModel == null)
            {
                return NotFound();
            }

            return itemCategoryModel;
        }

        // PUT: api/ItemCategory/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutItemCategoryModel(int id, ItemCategoryModel itemCategoryModel)
        {
            if (id != itemCategoryModel.ItemCategoryId)
            {
                return BadRequest();
            }

            _context.Entry(itemCategoryModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ItemCategoryModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ItemCategory
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ItemCategoryModel>> PostItemCategoryModel(ItemCategoryModel itemCategoryModel)
        {
            _context.itemCategoryModels.Add(itemCategoryModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetItemCategoryModel", new { id = itemCategoryModel.ItemCategoryId }, itemCategoryModel);
        }

        // DELETE: api/ItemCategory/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<ItemCategoryModel>> DeleteItemCategoryModel(int id)
        {
            var itemCategoryModel = await _context.itemCategoryModels.FindAsync(id);
            if (itemCategoryModel == null)
            {
                return NotFound();
            }

            _context.itemCategoryModels.Remove(itemCategoryModel);
            await _context.SaveChangesAsync();

            return itemCategoryModel;
        }

        private bool ItemCategoryModelExists(int id)
        {
            return _context.itemCategoryModels.Any(e => e.ItemCategoryId == id);
        }
    }
}
