import { GroceryItems } from './grocery-items.model';

describe('GroceryItems', () => {
  it('should create an instance', () => {
    expect(new GroceryItems()).toBeTruthy();
  });
});
