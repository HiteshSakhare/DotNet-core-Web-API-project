export class GroceryItems {
    itemId:number=0;
    itemName:string='';
    itemPrice:number;
    itemDiscription:string='';
    rating:string='';
    itemCategoryId:number=0;
    itemCategory:string='';
}
export class ItemCategory{
    itemCategoryId:number=0;
    itemCategory:string='';
}
