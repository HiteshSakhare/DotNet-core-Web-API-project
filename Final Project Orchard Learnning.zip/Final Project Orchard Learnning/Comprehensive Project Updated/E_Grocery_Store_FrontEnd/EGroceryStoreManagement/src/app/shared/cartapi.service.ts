import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartapiService {
  cartDataList:any=[];
  productList=new BehaviorSubject<any>([]);
  constructor(private http:HttpClient) { }
  getProductData(){
    return this.cartDataList.asObeservable();
  }
  setProduct(item:any){
    this.cartDataList.push(...item);
    this.productList.next(item);
  }
  addToCart(item:any){
    this.cartDataList.push(item);
    this.productList.next(this.cartDataList);
    this.getTotalAmount();
    console.log(this.cartDataList);
  }
  getTotalAmount(){
    let grandTotal=0;
    this.cartDataList.map((a:any)=>
    {
      grandTotal +=a.total;
    })
  }
  removeCartData(item:any){
    this.cartDataList.map((a:any,index:any)=>{
      if(item.id===a.id){
        this.cartDataList.splice(index,1);
      }
    })
  }
  removeAllCart(){
    this.cartDataList=[]
    this.productList.next(this.cartDataList)
  }
}
