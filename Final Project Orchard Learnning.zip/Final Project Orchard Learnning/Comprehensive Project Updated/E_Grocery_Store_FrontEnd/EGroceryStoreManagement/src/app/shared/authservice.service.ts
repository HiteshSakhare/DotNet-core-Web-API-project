import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { GroceryItems, ItemCategory } from './grocery-items.model';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  constructor(private myHttp:HttpClient) { }
  itemUrl:string='https://localhost:44322/api/GroceryItems';
  categoryUrl:string='https://localhost:44322/api/ItemCategory';

  listItem:GroceryItems[]=[];
  listCategory:ItemCategory[]=[];

  itemData:GroceryItems=new GroceryItems();

  saveItem(data:any){
    return this.myHttp.post('https://localhost:44322/api/GroceryItems/AddItems',data);
  }
  updateItem(){
    return this.myHttp.put(`${this.itemUrl}/${this.itemData.itemId}`,this.itemData);
  }
  getItem():Observable<GroceryItems[]>
  {
    return this.myHttp.get<GroceryItems[]>(this.itemUrl);
  }
  getCategory():Observable<ItemCategory[]>
  {
    return this.myHttp.get<ItemCategory[]>(this.categoryUrl);
  }
  deleteItem(itemId:number){
    return this.myHttp.delete(`${this.itemUrl}/${itemId}`)
  }

/*   Registration */

baseUrl="https://localhost:44322/api/";
//Register


postUserDetails(data:any){
  return this.myHttp.post("https://localhost:44322/api/Registration",data);
}
/* registerUser(){
 return this.myHttp.get("https://localhost:44322/api/Registration");
} */
/* postProduct(data:any){
  return this.myHttp.post<any>(this.baseUrl +"GroceryItems/AddItems",data);
}
getProduct(){
  return this.myHttp.get<any>(this.baseUrl +"GroceryItems/AddItems");
} */
//login
postUser(data:any){       
  return this.myHttp.get<any>("https://localhost:44322/api/Registration");
}

//Add-To-Cart

/* getProducts(){
  return this.myHttp.get("")
} */
}
