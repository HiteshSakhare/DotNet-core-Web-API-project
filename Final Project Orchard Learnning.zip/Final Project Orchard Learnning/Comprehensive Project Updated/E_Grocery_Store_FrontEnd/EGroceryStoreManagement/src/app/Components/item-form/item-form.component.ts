import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/shared/authservice.service';
import { GroceryItems } from 'src/app/shared/grocery-items.model';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.css']
})
export class ItemFormComponent implements OnInit {

  constructor(private http:HttpClient,private router:Router,public itemService:AuthserviceService) { }
@ViewChild('checkbox1') checkbox:ElementRef;
isSlide:string='off';
  ngOnInit(): void {
    this.itemService.getCategory().subscribe(data =>
      {
        this.itemService.listCategory=data;
      });
  }
  submit(form:NgForm){
    console.log(form.value);
    if(this.itemService.itemData.itemId==0){
      this.insertItem(form);
    }else{
      this.updateItem(form);
    }
  }
  insertItem(myForm:NgForm){

    this.itemService.saveItem(myForm.value).subscribe(res=>
      {
        console.log(res);
        alert("Grocery Item Added Successfully...! 😊");
        this.resetForm(myForm);
        this.refreshData();
        console.log("Save success.");
      })
    /* this.itemService.saveItem().subscribe(d=>
      {
        this.resetForm(myForm);
       this.refreshData();
       console.log("Save success.");
      }); */
  }
  updateItem(myForm:NgForm){
    this.itemService.updateItem().subscribe(data=>
      {
        alert("Grocery Item Updated Successfully...! 😊");
        this.resetForm(myForm);
       this.refreshData();
       console.log("Update success.");
      });
  }
  resetForm(myForm:NgForm){
    myForm.form.reset();
    this.itemService.itemData=new GroceryItems();
    this.hideShowChild();
  }
  refreshData(){
    this.itemService.getItem().subscribe(res=>
      {
        this.itemService.listItem=res;

      });
  }
  hideShowChild(){
    if(this.checkbox.nativeElement.checked){
      this.checkbox.nativeElement.checked=false;
      this.isSlide='off';
    }
    else{
      this.checkbox.nativeElement.checked=true;
      this.isSlide='on';
    }
  }
}
