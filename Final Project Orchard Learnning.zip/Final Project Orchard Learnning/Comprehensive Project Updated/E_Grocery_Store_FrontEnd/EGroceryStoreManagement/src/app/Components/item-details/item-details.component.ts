import { Component, OnInit,ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AuthserviceService } from 'src/app/shared/authservice.service';
import { GroceryItems } from 'src/app/shared/grocery-items.model';
import { ItemFormComponent } from '../item-form/item-form.component';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {

  constructor(public itemService:AuthserviceService,private dialog:MatDialog) { }
  @ViewChild(ItemFormComponent)emp:ItemFormComponent;
 /*  openDialog() {
    this.dialog.open(ItemFormComponent, {
      width:'30%'
    });
  } */

  ngOnInit(): void {
    this.itemService.getItem().subscribe(data=>
      {
        this.itemService.listItem=data;
      });
  }
  populateItem(selectedItem:GroceryItems){
    console.log(selectedItem);
    this.itemService.itemData=selectedItem;
    if(this.emp.isSlide==='off'){
      this.emp.hideShowChild();
    }
    
  }
  delete(id:number){
    if(confirm("Are you really want to delete this record?")){
      this.itemService.deleteItem(id).subscribe(data =>{
        console.log('Record Deleted...!');
        alert("Grocery Item Deleted Successfully..!");
        this.itemService.getItem().subscribe(data=>
          {
            this.itemService.listItem=data;
          });
      },err=>{
        console.log('Record not Deleted');
      });
    }
  }

}
