import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthserviceService } from 'src/app/shared/authservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //loginForm!:FormGroup;
  emailId:string;
  password:string;
  constructor(private formBuilder:FormBuilder,private http:HttpClient,
    private router:Router,private myService:AuthserviceService) { }

  ngOnInit(): void {
   /*  this.loginForm=this.formBuilder.group({
      emailId:[''],
      password:['']
    }) */
  }
  submitLogin(form:NgForm){
   this.login();
  }
  login(){
    if(this.emailId=="admin@gmail.com" && this.password=="Admin@123"){
      alert("Login Successfully..!  😊");
      this.router.navigate(['itemdetails'])
    }
    else if((this.emailId=="hitesh@gmail.com" && this.password=="Hitesh123")||
    (this.emailId=="pranali@gmail.com" && this.password=="Pranali@206")||
    (this.emailId=="minakshi@gmail.com" && this.password=="Minakshi@205")||
    (this.emailId=="pari@gmail.com" && this.password=="Pari@1012")||
    (this.emailId=="pankaj@gmail.com" && this.password=="Pankaj@123")){
      alert("Login Successfully..!  😊");
      this.router.navigate(['itemdisplay'])
    }
    else{
      alert("Invalid User Id or password! 😒 Enter Correct cardinals");

    }
    //myService.postUser(this.loginForm.value)
    /* this.http.get<any>("https://localhost:44322/api/registration").subscribe(res=>
      {
        const emailId=this.loginForm.value;
        const password=this.loginForm.value;
        const user=res.find((a:any)=>{
          return a.emailId===this.loginForm.value.emailId && a.password===this.loginForm.value.password
        })
        if(this.email=="admin@gmail.com" && this.passwordA=="Admin@123"){
          alert("Login Successfully..!");
          this.loginForm.reset();
          this.router.navigate(['itemdetails'])
        }
        if(user){
          alert("Login Successful..! 😊");
          this.loginForm.reset();
          this.router.navigate(['itemdisplay'])
        }
      },err=>{
        alert("Something Went Wrong..!😒");
      }) */

  }

}
